# mindcircuit13 - SAMPLE APP
